# Time-series-Weather-forecasting
In this project, i need to do weather forecasting using time series.i  use Keras and Recurrent Neural Network(RNN).
Predict the temperature column ‘ _tempm’ for Delhi, using Time Series Forecasting
# The training data is available from Jan 1996 - Nov 2016.
We will use data from Dec 2016 - April 2017 to check the model accuracy/validity.
# take inputs from weather_data.csv
1.clean the data
2.remove nan value
3.seperate the features and labels
4.scaling
# make the features_set input by in time sequences column 
make group 50 column.
# Model
Conclusion A long short-term memory network (LSTM) is one of the most commonly used neural networks for time series analysis. The ability of LSTM to remember previous information makes it ideal for such tasks.
